package finance.enumerations;

public enum Valuta {
    LEK, EURO, USD
}
