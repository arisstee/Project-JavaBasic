package finance.enumerations;

public enum Njesia {
    KG, COPE, PAKO, KOLI, TON
}
