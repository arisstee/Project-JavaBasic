package finance.data;

public class Furnitor {
    private String emri;
    private String NIPT;
    private String adresa;
    private LlogariBankare llogariaBankare;

    public String getEmri() {
        return emri;
    }

    public String getNIPT() {
        return NIPT;
    }

    public String getAdresa() {
        return adresa;
    }

    public LlogariBankare getLlogariaBankare() {
        return llogariaBankare;
    }
}
