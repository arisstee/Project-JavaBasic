package finance.data;

import java.util.ArrayList;

public class Fatura {
    private int nrFatures;
    private ArrayList<Artikull> artikuj;

    public Fatura(int nrFatures) {
        this.nrFatures = nrFatures;
        this.artikuj = new ArrayList<>();
    }

    public void shtoArtikull(Artikull a) {
        artikuj.add(a);
    }

    public double shumaFatures() {
        double total = 0;
        for(Artikull a : artikuj) {
            total += a.cmimiTotal();
        }
        return total;
    }

    public void printoFaturen() {
        System.out.println("Nr. Fatures: " + nrFatures);
        for(Artikull a : artikuj) {
            a.printoArtikull();
        }
        System.out.println("Shuma: " + shumaFatures());
    }
}
