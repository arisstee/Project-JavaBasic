package finance.data;

public class LlogariBankare {
    private String banka;
    private String IBAN;

    public LlogariBankare(String banka, String IBAN) {
        this.banka = banka;
        this.IBAN = IBAN;
    }

    public String getBanka() {
        return banka;
    }

    public String getIBAN() {
        return IBAN;
    }
}
