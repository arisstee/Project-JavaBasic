package finance.data;
import java.util.Date;

public class KerkeseBlerje {
    private String bleresi;
    private Date data;
    private Fatura fatura;

    public KerkeseBlerje(String bleresi, Date data, Fatura fatura) {
        this.bleresi = bleresi;
        this.data = data;
        this.fatura = fatura;
    }
    public void print() {
        // prints 80 *
        for (int i = 0; i < 80; i++) {
            System.out.print("*");
        }

    }
        public void printoKerkeseBlerje() {
        // printon kerkesen
        System.out.println("Bleresi: "+this.bleresi);
        System.out.println("Te dhenat: "+this.data);
        System.out.println("Fatura: "+this.fatura);
    }

}