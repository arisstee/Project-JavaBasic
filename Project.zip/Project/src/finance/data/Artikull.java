package finance.data;

import finance.enumerations.Njesia;
import finance.enumerations.Valuta;

public class Artikull {
    private int id;
    private String emri;
    private double cmimi;
    private Valuta valuta;
    private Njesia njesia;
    private int sasia;

    public Artikull(int id, String emri, double cmimi, Valuta valuta, Njesia njesia, int sasia) {
        this.id = id;
        this.emri = emri;
        this.cmimi = cmimi;
        this.valuta = valuta;
        this.njesia = njesia;
        this.sasia = sasia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmri() {
        return emri;
    }

    public void setEmri(String emri) {
        this.emri = emri;
    }

    public double getCmimi() {
        return cmimi;
    }

    public void setCmimi(double cmimi) {
        this.cmimi = cmimi;
    }

    public Valuta getValuta() {
        return valuta;
    }

    public void setValuta(Valuta valuta) {
        this.valuta = valuta;
    }

    public Njesia getNjesia() {
        return njesia;
    }

    public void setNjesia(Njesia njesia) {
        this.njesia = njesia;
    }

    public int getSasia() {
        return sasia;
    }

    public void setSasia(int sasia) {
        this.sasia = sasia;
    }


    public double cmimiTotal() {
        double cmimiTotal = cmimi * sasia;

        if(njesia == Njesia.PAKO && sasia == 6) {
            cmimiTotal = 6 * cmimi;
        } else if(njesia == Njesia.KOLI && sasia == 20) {
            cmimiTotal = 20 * cmimi;
        }

        return cmimiTotal;
    }

    public double cmimiTotalTVSH() {
        return cmimiTotal() * 1.2;
    }

    public void printoArtikull() {
        // printon te dhenat e artikullit

        System.out.println("ID e Artikullit: "+id);
        System.out.println("Emri i Artikullit: "+emri);
        System.out.println("Cmimi i Artikullit: "+cmimi);
        System.out.println("Valuta e Artikullit: "+valuta);
        System.out.println("Njesia e Artikulli: "+njesia);
        System.out.println("Sasia e Artikullit: "+sasia);
    }


}
