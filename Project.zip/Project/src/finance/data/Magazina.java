package finance.data;

public class Magazina {

    private int[][] artikuj;

    public Magazina(int[][] artikuj) {
        this.artikuj = artikuj;
    }

    public int[][] getArtikuj() {
        return artikuj;
    }
}
