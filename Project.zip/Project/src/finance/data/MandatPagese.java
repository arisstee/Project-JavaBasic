package finance.data;
import java.util.Date;

public class MandatPagese {
    private Fatura fatura;
    private Date dataPagese;
    private double shumaPagese;
    private Furnitor furnitori;
    private boolean dorezuar;


    public MandatPagese(Fatura fatura, Date dataPagese, double shumaPagese, Furnitor furnitori) {
        this.fatura = fatura;
        this.dataPagese = dataPagese;
        this.shumaPagese = shumaPagese;
        this.furnitori = furnitori;
    }
    public void printo() {
        // printon mandatin
        System.out.println("Fature: "+fatura);
        System.out.println("Te dhenat e Pageses: "+dataPagese);
        System.out.println("Shuma e Pagese: "+shumaPagese);
        System.out.println("Furnitori: "+furnitori);
    }

}
